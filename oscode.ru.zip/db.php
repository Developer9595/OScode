<?php
    require "rb.php";
    R::setup( 'mysql:host=localhost;dbname=v91178na_oscoderu',
        'admin', '0123456789' );

session_start();