<?php 
    mysqli_connect("localhost", "root", "", "search") or di
?>